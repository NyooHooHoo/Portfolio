/**
 * <h1>Elf Class - Fantasy Game Assignment</h1>
 * Servants of the dragon who explore castles to collect gold
 *
 * <h2>Course Info:</h2>
 * ICS4U0 with V. Krasteva
 * @version 04/21/2023
 * @author Aidan Wang, Lauren Hewang
 */
class Elf extends Character {
	final static int maxGold = 30;
	
	Elf(String name)
	{
		super(name);
	}
	
	/**
	 * Takes the maximum amount of gold and returns the leftover amount.
	 * @param available The amount of gold available to be taken.
	 * @return The amount of gold leftover.
	 */
	int takeGold(int available)
	{
		int taken;
		if (available + gold <= maxGold)
		{
			gold += available;
			taken = available;
		}
		else
		{
			gold = maxGold;
			taken = available - maxGold;
		}
		
		System.out.println(getName() + " takes " + taken + " gold. Gold=" + gold + " bars");
		
		return available - taken;
	}
	
	/**
	 * Reduce the health by 10%.
	 */
	void exposeToRadiation()
	{
		health = (int)(health * 0.9);
		
		System.out.println(getName() + " is exposed to radiation. Health=" + health + "%");
	}

	/**
	 * Reduce health by 40% when dragon breathes fire
	 */
	void burn()
	{
		health = (int)(health * 0.6);
		System.out.println(getName() + " burns from fire! Health=" + health + "%");
	}

	/**
	 * A description of this Elf.
	 * @return String with elf name
	 */
	String getName() {
		return "Elf " + name;
	}
}
