/**
 * <h1>Main Class - Fantasy Game Assignment</h1>
 * Driver to run the Fantasy Game
 *
 * <h2>Course Info:</h2>
 * ICS4U0 with V. Krasteva
 * @version 04/21/2023
 * @author Aidan Wang, Lauren Hewang
 */
public class Main {
	public static void main(String[] args) {
		Game game = new Game();
		game.play();
	}
}
