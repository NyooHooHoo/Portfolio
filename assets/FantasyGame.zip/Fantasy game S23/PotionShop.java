public class PotionShop {
    private final String name;
    private int revenue;
    private static final int price = 5;

    public PotionShop(String name) {
        this.name = name;
        revenue = 0;
    }

    public void acceptPayment(Character c, int num) {
        if (c.getGold() < price * num)
            System.out.println("Sorry " + c.getName() + ", you don't have enough gold to buy " + num + " potions from" + getName());
        else {
            c.gold -= price * num;
            revenue += price * num;
            System.out.println(getName() + " accepts payment from " + c.getName() + ". Revenue=" + getRevenue() + " bars");
            serve(c, num);
        }
    }

    public void serve(Character c, int num) {
        c.potions += num;
        System.out.println(c.getName() + " receives " + num + " potion(s) from " + getName());
    }

    public String getName() {
        return name;
    }

    public int getRevenue() {
        return revenue;
    }
}
