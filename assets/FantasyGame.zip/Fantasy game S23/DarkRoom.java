import java.util.ArrayList;

/**
 * <h1>DarkRoom Class - Fantasy Game Assignment</h1>
 * DarkRooms have certain properties that elves can interact with.
 *
 * <h2>Course Info:</h2>
 * ICS4U0 with V. Krasteva
 * @version 04/21/2023
 * @author Aidan Wang, Lauren Hewang
 */
class DarkRoom {
	String name;
	int gold;
	boolean radioactive;
	
	ArrayList<Elf> elves;
	
	/**
	 * Constructs a DarkRoom
	 * @param name The name of the room.
	 * @param gold The amount of the gold.
	 * @param radioactive If radioactivity is present
	 */
	DarkRoom(String name, int gold, boolean radioactive)
	{
		this.name = name;
		this.gold = gold;
		this.radioactive = radioactive;
		
		elves = new ArrayList<>();
	}
	
	/**
	 * Have Elf interact with DarkRoom.
	 * @param elf Elf object to interact with
	 */
	void enter(Elf elf)
	{
		elves.add(elf);
		
		if (radioactive)
			elf.exposeToRadiation();
		
		gold = elf.takeGold(gold);
	}
	
	/**
	 * Remove Elf from room.
	 * @param elf Elf object to remove
	 */
	void exit(Elf elf)
	{
		elves.remove(elf);
	}

	/**
	 * A description of this DarkRoom
	 * @return String of DarkRoom name
	 */
	String getName() {
		return name;
	}
}