public abstract class Character {
    String name;
    int health;
    int gold;
    int potions;

    Character(String name) {
        this.name = name;
        health = 100;
        gold = 0;
        potions = 0;
    }

    /**
     * Drinking potion restores health.
     */
    void drinkPotion() {
        if (potions > 0) {
            health = 100;
            System.out.println(getName() + " drinks potion. Health=" + health + "%");
        }
        else
            System.out.println(getName() + " tried to drink a potion but doesn't have any!");
    }

    void buyPotion(PotionShop p, int num) {
        p.acceptPayment(this, num);
    }

    abstract String getName();

    int getHealth() {
        return health;
    }

    int getGold() {
        return gold;
    }
}
