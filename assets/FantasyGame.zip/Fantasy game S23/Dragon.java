public class Dragon extends Character{
    public final static int minGoldTolerance = 25;

    public Dragon(String name) 	{
        super(name);
    }

    public void collectGold(Elf elf) {
        int taken = elf.getGold();
        this.gold += taken;
        elf.gold = 0;
        System.out.println(getName() + " takes all " + taken + " gold from " + elf.getName() + ". Gold=" + gold + " bars");
        if (taken < minGoldTolerance)
            breatheFire(elf);
    }

    public void breatheFire(Elf elf) {
        System.out.println(getName() + " is angry at " + elf.getName() + " for not bringing enough gold and breathes fire on them.");
        elf.burn();
        health = (int)(health * 0.9);
        System.out.println(getName() + " hurts themself breathing fire and takes damage! Health=" + health + "%");
    }

    public String getName() {
        return "Dragon " + this.name;
    }
}
