import java.util.ArrayList;

/**
 * <h1>Castle Class - Fantasy Game Assignment</h1>
 * Location with DarkRooms filled with gold for the elves to collect.
 *
 * <h2>Course Info:</h2>
 * ICS4U0 with V. Krasteva
 * @version 04/21/2023
 * @author Aidan Wang, Lauren Hewang
 */
class Castle {
	ArrayList<DarkRoom> rooms;
	
	Castle()
	{
		rooms = new ArrayList<>();
	}
	
	/**
	 * Adds a DarkRoom to the Castle level
	 * @param room DarkRoom object to add
	 */
	void addRoom(DarkRoom room)
	{
		rooms.add(room);
	}
	
	/**
	 * Occurs when an Elf enters a DarkRoom
	 * @param elf The Elf
	 * @param room The DarkRoom
	 */
	void enterRoom(Elf elf, DarkRoom room)
	{
		System.out.println(elf.getName() + " enters the " + room.getName() );
		room.enter(elf);
	}
	
	/**
	 * Occurs when an Elf leaves a DarkRoom.
	 * @param elf The Elf.
	 * @param room The DarkRoom
	 */
	void exitRoom(Elf elf, DarkRoom room)
	{
		room.exit(elf);
		
		System.out.println(elf.getName() + " leaves the " + room.getName() );
	}
	
	/**
	 * Returns the number of DarkRooms.
	 * @return The number of DarkRooms.
	 */
	int getRoomCount()
	{
		return rooms.size();
	}

	/**
	 * Returns a DarkRoom according to index.
	 * @param index index of DarkRoom in list
	 * @return the specified DarkRoom
	 */
	DarkRoom getRoom(int index) {
		return rooms.get(index);
	}
}
