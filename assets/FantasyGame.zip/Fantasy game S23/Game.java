/**
 * <h1>Game Class - Fantasy Game Assignment</h1>
 * [description]
 *
 * <h2>Course Info:</h2>
 * ICS4U0 with V. Krasteva
 * @version 04/21/2023
 * @author Aidan Wang, Lauren Hewang
 */
public class Game {

	/**
	 * Initiates the start of game play.
	 */
	void play() {
		Castle castle = new Castle();
		createLevel1(castle);
		PotionShop shop = new PotionShop("Poppy's Potions");
		
		Elf elf = new Elf("Sam");
		Dragon dragon = new Dragon("Gary");

		System.out.println(elf.getName() + " enters a castle.");
		for (int i=0; i<castle.getRoomCount(); i++)
		{
			DarkRoom room = castle.getRoom(i);
			castle.enterRoom(elf, room);
			castle.exitRoom(elf, room);
			if (elf.getHealth() < 30) {
				System.out.println(elf.getName() + " has reached critical health and must leave the castle!");
				break;
			}
		}

		elf.drinkPotion(); // First time doesn't have any
		elf.buyPotion(shop, 2);
		elf.drinkPotion(); // Second time is able to drink a potion

		System.out.println(elf.getName() + " approaches " + dragon.getName() + " to deliver the gold.");
		dragon.collectGold(elf);

		dragon.drinkPotion(); // First time doesn't have any
		dragon.buyPotion(shop, 1);
		dragon.drinkPotion(); // Second time is able to drink a potion
		elf.drinkPotion();

		System.out.println("Everyone is healthy again!");
	}

	/**
	 * Constructs one level of the game for a character.
	 * @param castle Castle object to build rooms in
	 */
	void createLevel1(Castle castle)
	{
		DarkRoom room = new DarkRoom("foyer", 10, true);
		castle.addRoom(room);
		
		room = new DarkRoom("kitchen", 7, false);
		castle.addRoom(room);
		
		room = new DarkRoom("living room", 0, true);
		castle.addRoom(room);
	}
}
