import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * <h1>Ratings Assignment - Driver</h1>
 * <h2>Course Info:</h2>
 * ICS4U0 with V. Krasteva
 *
 * @version 03.03.2023
 * @author Aidan Wang, Lauren Hewang
 */
public class Driver {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("What version of the program would you like to run?");
        int version = keyboard.nextInt();
        if (version == 1) {
            DogRatingsParallel drp = new DogRatingsParallel();
            drp.menu();
        }
        else if (version == 2) {
            Scanner data = new Scanner(new File("data.txt"));
            DogRatings2D dr2 = new DogRatings2D(data);
            dr2.menu();
        }
    }
}