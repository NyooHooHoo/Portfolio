import java.util.Scanner;

/**
 * <h1>Ratings Assignment - Version 1: Parallel Arrays</h1>
 * <h2>Course Info:</h2>
 * ICS4U0 with V. Krasteva
 *
 * @version 03.03.2023
 * @author Aidan Wang, Lauren Hewang
 */
public class DogRatingsParallel {
    private String[] dogBreeds;
    private int[] maintenance, energy, lifespan, amicability, appearance;

    /**
     * Constructor class initializes array values and checks for out of range ratings
     */
    public DogRatingsParallel() {
        dogBreeds = new String[]{"Golden Retriever", "Pomeranian", "Poodle", "Corgi", "German Sheppard",
        "Chihuahua", "Bulldog", "Samoyed", "Dachshund", "Teddy Bear Dog"};
        maintenance = new int[]{5, 5, 3, 13, 4, -5, 10, 7, 10, 3};
        maintenance = makeInRange(maintenance);
        energy = new int[]{11, 7, 3, 11, 10, 0, -2, 9, 5, 4};
        energy = makeInRange(energy);
        lifespan = new int[]{5, 8, 4, 11, 4, -3, 3, 8, 6, 7};
        lifespan = makeInRange(lifespan);
        amicability = new int[]{12, 10, 3, 900000, 7, -12, 2, 9, 8, 9};
        amicability = makeInRange(amicability);
        appearance = new int[]{10, 10, 1, 100, 6, -40, -5, 9, 12, 30};
        appearance = makeInRange(appearance);
    }

    /**
     * Menu method calls all other methods in while loop until user quits program
     */
    public void menu(){
        Scanner s = new Scanner(System.in);
        System.out.println("Welcome to Dog Rating Mania! Ten dog breeds have been rated on a scale from " +
                "1 to 10 in 5 different categories. Their final scores are calculated based on a weighted average: ");
        System.out.println("Ease of Maintenance (25%), Energy Level (10%), Lifespan (10%), Amicability (30%), and Appearance (25%).");
        while (true){
            System.out.println("Enter [1] to display all the dogs and their scores.");
            System.out.println("Enter [2] to see the best dog breed overall.");
            System.out.println("Enter [3] to see the best dog breed in each category.");
            System.out.println("Enter [4] to exit the program.");
            int input = s.nextInt();
            if (input == 1) {
                displayAll();
            }
            else if (input == 2) {
                displayBest();
            }
            else if (input == 3) {
                displayBestInCategories(maintenance, "maintenance");
                displayBestInCategories(energy, "energy");
                displayBestInCategories(lifespan, "lifespan");
                displayBestInCategories(amicability, "amicability");
                displayBestInCategories(appearance, "appearance");
            }
            else if (input == 4) {
                break;
            }
        }
    }

    /**
     * Displays rating for each category of each dog breed
     */
    public void displayAll(){
        for(int i=0; i<dogBreeds.length; i++){
            System.out.println(dogBreeds[i]);
            System.out.println("Ease of Maintenance: " + maintenance[i]);
            System.out.println("Energy Level: " + energy[i]);
            System.out.println("Lifespan: " + lifespan[i]);
            System.out.println("Amicability: " + amicability[i]);
            System.out.println("Appearance: " + appearance[i]);
            System.out.println();
        }
    }

    /**
     * Displays the best dog breed overall based on weighted average rating
     */
    public void displayBest(){
        double average;
        double greatest = 0;
        String greatestBreed = "";
        for(int i=0; i<dogBreeds.length; i++){
            average = (0.25*maintenance[i] + 0.1*energy[i] + 0.1*lifespan[i] + 0.3*amicability[i] + 0.25*appearance[i]);
            if(average>greatest){
                greatest = average;
                greatestBreed = dogBreeds[i];
            }
        }
        System.out.println(greatestBreed + " is the best dog breed overall, with an average of " + greatest + "\n");
    }

    /**
     * Displays the best scoring dog breed(s) in a specified category
     *
     * @param category array of ratings for category
     * @param cat string for name of category
     */
    public void displayBestInCategories(int[] category, String cat){
        int best = 0;
        String bestBreed = "";
        for(int i=0; i<category.length; i++){ // New highest rating
            if(category[i] > best){
                bestBreed = dogBreeds[i];
                best = category[i];
            }
            else if (category[i] == best) { // Tie for highest rating
                if (!bestBreed.equals(""))
                    bestBreed += ", ";
                bestBreed += dogBreeds[i];
            }
        }
        System.out.println("The best dog breed(s) for " + cat + " is/are " + bestBreed + ", with score(s) of " + best + ".\n");
    }

    /**
     * Checks all rating values in an array and changes out of range values with highest/lowest bounds
     *
     * @param arr array to check values of
     * @return new array with only in range values
     */
    public int[] makeInRange(int[] arr){
        for(int i=0; i<arr.length; i++){
            if(arr[i]<1)
                arr[i]=1;
            if(arr[i]>10)
                arr[i]=10;
        }
        return arr;
    }
}
