import java.util.Scanner;

/**
 * <h1>Ratings Assignment - Version 1: 2D Array</h1>
 * <h2>Course Info:</h2>
 * ICS4U0 with V. Krasteva
 *
 * @version 03.03.2023
 * @author Aidan Wang, Lauren Hewang
 */
public class DogRatings2D {
    private String[] dogBreeds, categories;
    private int[][] ratings;

    /**
     * Constructor class reads data from file and checks for out of range ratings
     *
     * @param d Scanner object to read from data file
     */
    public DogRatings2D(Scanner d) {
        dogBreeds = new String[10];
        ratings = new int[5][10];
        categories = new String[]{"maintenance", "energy", "lifespan", "amicability", "appearance"};
        for (int i = 0; i < dogBreeds.length; i++) {
            dogBreeds[i] = d.nextLine();
            for (int j = 0; j < 5; j++) {
                ratings[j][i] = d.nextInt();
                if (i != dogBreeds.length - 1)
                    d.nextLine();
                if (ratings[j][i] > 10)
                    ratings[j][i] = 10;
                else if (ratings[j][i] < 1)
                    ratings[j][i] = 1;
            }
        }
    }

    /**
     * Menu method calls all other methods in while loop until user quits program
     */
    public void menu() {
        Scanner s = new Scanner(System.in);
        System.out.println("Welcome to Dog Rating Mania! Ten dog breeds have been rated on a scale from " +
                "1 to 10 in 5 different categories. Their final scores are calculated based on a weighted average: ");
        System.out.println("Ease of Maintenance (25%), Energy Level (10%), Lifespan (10%), Amicability (30%), and Appearance (25%).");
        while (true){
            System.out.println("Enter [1] to display all the dogs and their scores.");
            System.out.println("Enter [2] to see the best dog breed overall.");
            System.out.println("Enter [3] to see the best dog breed in each category.");
            System.out.println("Enter [4] to exit the program.");
            int input = s.nextInt();
            if (input == 1) {
                displayAll();
            }
            else if (input == 2) {
                displayBest();
            }
            else if (input == 3) {
                displayBestInCategories();
            }
            else if (input == 4) {
                break;
            }
        }

    }

    /**
     * Displays rating for each category of each dog breed
     */
    public void displayAll() {
        for(int i=0; i<dogBreeds.length; i++){
            System.out.println(dogBreeds[i]);
            System.out.println("Ease of Maintenance: " + ratings[0][i]);
            System.out.println("Energy Level: " + ratings[1][i]);
            System.out.println("Lifespan: " + ratings[2][i]);
            System.out.println("Amicability: " + ratings[3][i]);
            System.out.println("Appearance: " + ratings[4][i]);
            System.out.println();
        }
    }

    /**
     * Displays the best dog breed overall based on weighted average rating
     */
    public void displayBest() {
        double average;
        double greatest = 0;
        String greatestBreed = "";
        for(int i=0; i<dogBreeds.length; i++){
            average = (0.25*ratings[0][i] + 0.1*ratings[1][i] + 0.1*ratings[2][i] + 0.3*ratings[3][i] + 0.25*ratings[4][i]);
            if(average>greatest){
                greatest = average;
                greatestBreed = dogBreeds[i];
            }
        }
        System.out.println(greatestBreed + " is the best dog breed overall, with an average of " + greatest + "\n");

    }

    /**
     * Displays the best scoring dog breed(s) in each category
     */
    public void displayBestInCategories(){
        int best;
        String bestBreed;
        int[] category;
        for (int j = 0; j < ratings.length; j++) {
            category = ratings[j];
            best = 0;
            bestBreed = "";
            for (int i = 0; i < category.length; i++) {
                if (category[i] > best) { // New highest rating
                    bestBreed = dogBreeds[i];
                    best = category[i];
                }
                else if (category[i] == best) { // Tie for highest rating
                    if (!bestBreed.equals(""))
                        bestBreed += ", ";
                    bestBreed += dogBreeds[i];
                }
            }
            System.out.println("The best dog breed(s) for " + categories[j] + " is/are " +
                    bestBreed + ", with score(s) of " + best + ".\n");
        }
    }
}
