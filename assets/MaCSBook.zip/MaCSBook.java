import java.io.*;
import java.util.*;

/**
 * <h1>MaCSBook Class</h1>
 * Takes in, stores, and manipulates the names, numbers, marks, and averages of MaCS students.
 *
 * <h2>Course Info:</h2>
 * ICS4U0 with Krasteva, V
 *
 * @version 03.22.2023
 * @author Aidan Wang, Rita Xu, Matthew Tsui (original Lauren Hewang, Aidan Wang)
 */
public class MaCSBook {
    private ArrayList<String> names;
    private ArrayList<Integer> numbers;
    private ArrayList<Double> assignmentMarks, testMarks, finalProjectMarks, studentAverages;
    private double classAverage;
    private Scanner scanner, keyboard;
    private FileWriter writer;

    /**
     * Class constructor initializes each String ArrayList.
     *
     * @param f File that stores all pre-existing student information.
     */
    public MaCSBook(File f) throws IOException {
        names = new ArrayList<>();
        numbers = new ArrayList<>();
        assignmentMarks = new ArrayList<>();
        testMarks = new ArrayList<>();
        finalProjectMarks = new ArrayList<>();
        studentAverages = new ArrayList<>();
        scanner = new Scanner(f);
        keyboard = new Scanner(System.in);
        writer = new FileWriter(f, true);
    }

    /**
     * menu() method Main menu of the program welcomes user, gives instructions, and calls meethods based on option chosen by user.
     */
    public void menu() throws IOException {
        System.out.println("Welcome! This is a MaCS Book program that stores the names, student numbers,");
        System.out.println("and marks of students and finds the personal and class averages of the marks.");

        // Reading any previously stored data in file
        while (scanner.hasNext()) {
            names.add(scanner.nextLine());
            numbers.add(Integer.parseInt(scanner.nextLine()));
            assignmentMarks.add(Double.parseDouble(scanner.nextLine()));
            testMarks.add(Double.parseDouble(scanner.nextLine()));
            finalProjectMarks.add(Double.parseDouble(scanner.nextLine()));
            studentAverages.add(Double.parseDouble(scanner.nextLine()));
        }

        // Main menu loop
        String optionString;
        while (true) {
            System.out.println("""
                Please enter:
                1 to create data
                2 to view all data
                3 to view a specific student's data
                4 to change a student's name
                5 to change a student's mark
                6 to sort students alphabetically
                7 to sort students by average grade
                8 to exit the program""");
            optionString = keyboard.nextLine();
            while (!optionString.matches("[1-8]")) {
                System.out.println("Please enter a valid option!");
                optionString = keyboard.nextLine();
            }
            while (optionString.matches("[2-7]") && names.isEmpty()) {
                System.out.println("Data must first be created to perform that function!");
                optionString = keyboard.nextLine();
            }
            int option = Integer.parseInt(optionString);

            // Create data
            if (option == 1)
                createData();

            // View all data
            if (option == 2){
                viewAllData();
            }

            // View specific student data
            else if (option == 3) {
                System.out.print("Would you like to enter the student's NAME or NUMBER? Enter in all caps: ");
                optionString = keyboard.nextLine();
                while (!optionString.matches("NAME|NUMBER")) {
                    System.out.println("Please enter only NAME or NUMBER!");
                    optionString = keyboard.nextLine();
                }
                if (optionString.equals("NAME")) {
                    System.out.print("Enter the name of the student you'd like to view: ");
                    viewStudentData(keyboard.nextLine());
                }
                else if (optionString.equals("NUMBER")) {
                    System.out.print("Enter the number of the student you'd like to view: ");
                    viewStudentData(Integer.parseInt(keyboard.nextLine()));
                }
            }

            // Change student name/mark
            else if (option == 4 || option == 5) {
                String numString;
                System.out.print("Enter the number of the student you'd like to change: ");
                numString = keyboard.nextLine();
                while (!numString.matches("[1-9][0-9]{8}")) {
                    System.out.println("Please only enter a 9 digit number!");
                    numString = keyboard.nextLine();
                }
                if (option == 4) changeName(Integer.parseInt(numString));
                else changeMark(Integer.parseInt(numString));
            }

            // Sort by name
            else if (option == 6) {
                sortNames();
            }

            // Sort by mark
            else if (option == 7) {
                sortMarks();
            }

            // Exit application
            else if (option == 8) {
                System.out.println("Exiting...");
                scanner.close();
                keyboard.close();
                writer.close();
                break;
            }
        }
    }

    /**
     * createData() method Allows user to create names, numbers, and marks of students while making sure inputs are valid and in range.
     */
    public void createData() throws IOException {
        // Number of students to add
        System.out.println("How many new students would you like to add?");
        int original = names.size();
        String num = keyboard.nextLine();
        while (true) {
            if (!num.matches("[1-9][0-9]*")) {
                System.out.println("Please enter an integer!");
                num = keyboard.nextLine();
                continue;
            }
            else if (Integer.parseInt(num) + original < 5 || Integer.parseInt(num) + original > 10) {
                System.out.println("That is out of the 5-10 student limit! Please enter another number.");
                num = keyboard.nextLine();
                continue;
            }
            break;
        }
        int realNum = Integer.parseInt(num);

        // Names
        System.out.println("Please enter the names of the " + realNum + " new students:");
        for (int i = 0; i < realNum; i++)
            names.add(keyboard.nextLine());

        // Student numbers
        System.out.println("Please enter the student number (9 digit) for each new student:");
        String line;
        for (int i = original; i < realNum + original; i++) {
            System.out.print(names.get(i) + ": ");
            line = keyboard.nextLine();
            while (true) {
                if (!line.matches("[1-9][0-9]{8}")) {
                    System.out.println("Please enter a 9 digit number!");
                    System.out.print(names.get(i) + ": ");
                    line = keyboard.nextLine();
                    continue;
                }
                else if (numbers.contains(Integer.parseInt(line))) {
                    System.out.println("That number is already being used!");
                    System.out.print(names.get(i) + ": ");
                    line = keyboard.nextLine();
                    continue;
                }
                break;
            }
            numbers.add(Integer.parseInt(line));
        }

        // Assignment Marks
        System.out.println("Please enter the assignment mark (0-100%) for each new student:");
        for (int i = original; i < realNum + original; i++) {
            System.out.print(names.get(i) + ": ");
            line = keyboard.nextLine();
            while (!line.matches("(100|[1-9]?\\d)(\\.\\d+)?")) {
                System.out.println("Please enter a valid grade!");
                System.out.print(names.get(i) + ": ");
                line = keyboard.nextLine();
            }
            assignmentMarks.add(Double.parseDouble(line));
        }

        // Test Marks
        System.out.println("Please enter the test mark (0-100%) for each new student:");
        for (int i = original; i < realNum + original; i++) {
            System.out.print(names.get(i) + ": ");
            line = keyboard.nextLine();
            while (!line.matches("(100|[1-9]?\\d)(\\.\\d+)?")) {
                System.out.println("Please enter a valid grade!");
                System.out.print(names.get(i) + ": ");
                line = keyboard.nextLine();
            }
            testMarks.add(Double.parseDouble(line));
        }

        // Final Project Mark
        System.out.println("Please enter the final project mark (0-100%) for each new student:");
        for (int i = original; i < realNum + original; i++) {
            System.out.print(names.get(i) + ": ");
            line = keyboard.nextLine();
            while (!line.matches("(100|[1-9]?\\d)(\\.\\d+)?")) {
                System.out.println("Please enter a valid grade!");
                System.out.print(names.get(i) + ": ");
                line = keyboard.nextLine();
            }
            finalProjectMarks.add(Double.parseDouble(line));
        }

        // Calculate Student Averages
        for (int i = original; i < realNum + original; i++)
            studentAverages.add((assignmentMarks.get(i) + testMarks.get(i) + finalProjectMarks.get(i)) / 3);

        // Calculate Class Average
        double sum = 0;
        for (double average : studentAverages)
            sum += average;
        classAverage = sum / studentAverages.size();

        // Writing to File
        for (int i = original; i < realNum + original; i++) {
            writer.write(names.get(i) + "\n");
            writer.write(numbers.get(i) + "\n");
            writer.write(assignmentMarks.get(i) + "\n");
            writer.write(testMarks.get(i) + "\n");
            writer.write(finalProjectMarks.get(i) + "\n");
            writer.write(studentAverages.get(i) + "\n");
        }
    }

    /**
     * viewAllData() method Displays all students' names, numbers, and individual marks.
     */
    public void viewAllData() {
        for(int i = 0; i < names.size(); i++){
            System.out.println("Student name: " + names.get(i));
            System.out.println("Student number: " + numbers.get(i));
            System.out.println("Assignment mark: " + assignmentMarks.get(i) + "%");
            System.out.println("Test mark: " + testMarks.get(i) + "%");
            System.out.println("Final project mark: " + finalProjectMarks.get(i) + "%");
            System.out.printf("%s%.2f%%%n%n", "Student average: ", studentAverages.get(i));
        }
    }

    /**
     * viewStudentData(String name) method Displays name, number, and individual marks of a specific student, retrieved by using the student's name.
     *
     * @param name The name of the student whose information is presented.
     */
    public void viewStudentData(String name) {
        int a = 0;
        int in = 0;
        for(int i = 0; i < names.size(); i++){
            if(names.get(i).equals(name)){
                in = i;
                a++;
            }
        }
        if(a==1){
            System.out.println("Student name: " + names.get(in));
            System.out.println("Student number: " + numbers.get(in));
            System.out.println("Assignment mark: " + assignmentMarks.get(in));
            System.out.println("Test mark: " + testMarks.get(in));
            System.out.println("Final project mark: " + finalProjectMarks.get(in));
            System.out.printf("%s%.2f%n%n", "Student average: ", studentAverages.get(in));
        }else if(a==0){
            System.out.println("Sorry, " + name + " does not exist in this MaCS Book.");
        }else if(a>1){ // if there is more than one person with this name, this student's data can only be retrieved by using thier number.
            System.out.println("There is more than one student named " + name + ". Please enter this student's number instead: ");
            viewStudentData(Integer.parseInt(keyboard.nextLine()));
        }
    }

    /**
     * viewStudentData(int number) method Displays name, number, and individual marks of a specific student, retrieved by using the student's number.
     *
     * @param number The student number of the student whose information is presented.
     */
    public void viewStudentData(int number) {
        boolean found = false;
        for(int i = 0; i < names.size(); i++){
            if(numbers.get(i) == number){
                System.out.println("\nStudent name: " + names.get(i));
                System.out.println("Student number: " + numbers.get(i));
                System.out.println("Assignment marks: " + assignmentMarks.get(i));
                System.out.println("Test marks: " + testMarks.get(i));
                System.out.println("Final project marks: " + finalProjectMarks.get(i));
                System.out.println();
                found = true;
            }
        }
        if(!found)
            System.out.println("This student number does not exist in this MaCS Book.\n");
    }

    /**
     * Changes a student's name and rewrites data file accordingly
     *
     * @param number student number of student to be changed
     * @throws IOException handles exceptions with FileWriter
     */
    public void changeName(int number) throws IOException {
        if (numbers.contains(number)) {
            int studentIndex = 0;
            for (int i = 0; i < numbers.size(); i++) {
                if (numbers.get(i) == number) {
                    studentIndex = i;
                    break;
                }
            }
            String newName;
            System.out.print("Enter " + names.get(studentIndex) + "'s new name: ");
            newName = keyboard.nextLine();
            names.set(studentIndex, newName);
            new FileWriter("data.txt", false).close();
            for (int i = 0; i < names.size(); i++) {
                writer.write(names.get(i) + "\n");
                writer.write(numbers.get(i) + "\n");
                writer.write(assignmentMarks.get(i) + "\n");
                writer.write(testMarks.get(i) + "\n");
                writer.write(finalProjectMarks.get(i) + "\n");
                writer.write(studentAverages.get(i) + "\n");
            }
        }
        else {
            System.out.println("This student number does not exist in this MaCS Book.\n");
        }
    }

    /**
     * Changes one of a student's marks, recalculates their average, and rewrites data file accordingly
     *
     * @param number student number of student to be changed
     * @throws IOException handles exceptions with FileWriter
     */
    public void changeMark(int number) throws IOException {
        if (numbers.contains(number)) {
            int studentIndex = 0;
            for (int i = 0; i < numbers.size(); i++) {
                if (numbers.get(i) == number) {
                    studentIndex = i;
                    break;
                }
            }
            System.out.println("Enter 'A' to change " + names.get(studentIndex) + "'s assignment mark");
            System.out.println("Enter 'B' to change " + names.get(studentIndex) + "'s test mark");
            System.out.println("Enter 'C' to change " + names.get(studentIndex) + "'s final project mark");
            String markToChange = keyboard.nextLine();
            while (!markToChange.matches("[ABC]")) {
                System.out.println("Please enter a valid option!");
                markToChange = keyboard.nextLine();
            }
            System.out.print("Enter " + names.get(studentIndex) + "'s new mark: ");
            String newMarkString = keyboard.nextLine();
            while (!newMarkString.matches("(100|[1-9]?\\d)(\\.\\d+)?")) {
                System.out.println("Please enter a valid grade!");
                System.out.print(names.get(studentIndex) + "'s new mark: ");
                newMarkString = keyboard.nextLine();
            }
            double newMark = Double.parseDouble(newMarkString);
            switch (markToChange) {
                case "A" -> assignmentMarks.set(studentIndex, newMark);
                case "B" -> testMarks.set(studentIndex, newMark);
                case "C" -> finalProjectMarks.set(studentIndex, newMark);
            }
            studentAverages.set(studentIndex, (assignmentMarks.get(studentIndex) + testMarks.get(studentIndex)
                    + finalProjectMarks.get(studentIndex)) / 3);
            System.out.printf("%s%s%.2f%%%n%n", names.get(studentIndex), "'s new average is ", studentAverages.get(studentIndex));
            new FileWriter("data.txt", false).close();
            for (int i = 0; i < names.size(); i++) {
                writer.write(names.get(i) + "\n");
                writer.write(numbers.get(i) + "\n");
                writer.write(assignmentMarks.get(i) + "\n");
                writer.write(testMarks.get(i) + "\n");
                writer.write(finalProjectMarks.get(i) + "\n");
                writer.write(studentAverages.get(i) + "\n");
            }
        }
        else {
            System.out.println("This student number does not exist in this MaCS Book.\n");
        }
    }

    /**
     * sortNames() method sorts data alphabetically by name using insertion sort
     *   > Method added to originally program by Rita
     */
    public void sortNames() throws IOException {
        for(int i=1; i<names.size(); i++) {
            for(int j=0; j<i; j++) {
                int compare = names.get(i).toLowerCase().compareTo(names.get(j).toLowerCase());

                if(compare<0) {
                    names.add(j, names.get(i));
                    numbers.add(j, numbers.get(i));
                    assignmentMarks.add(j, assignmentMarks.get(i));
                    testMarks.add(j, testMarks.get(i));
                    finalProjectMarks.add(j, finalProjectMarks.get(i));
                    studentAverages.add(j, studentAverages.get(i));

                    names.remove(i+1);
                    numbers.remove(i+1);
                    assignmentMarks.remove(i+1);
                    testMarks.remove(i+1);
                    finalProjectMarks.remove(i+1);
                    studentAverages.remove(i+1);
                    break;
                }
                else if(compare==0) {
                    names.add(j+1, names.get(i));
                    numbers.add(j+1, numbers.get(i));
                    assignmentMarks.add(j+1, assignmentMarks.get(i));
                    testMarks.add(j+1, testMarks.get(i));
                    finalProjectMarks.add(j+1, finalProjectMarks.get(i));
                    studentAverages.add(j+1, studentAverages.get(i));

                    names.remove(i+1);
                    numbers.remove(i+1);
                    assignmentMarks.remove(i+1);
                    testMarks.remove(i+1);
                    finalProjectMarks.remove(i+1);
                    studentAverages.remove(i+1);
                }
            }
        }
        printSorted();
    }

    /**
     * sortMarks() method sorts data in descending order based on average marks using selection sort
     *  > Method added to original program by Matthew Tsui
     */
    public void sortMarks() throws IOException {
        for (int i = 0; i < studentAverages.size() - 1; i++) {
            for (int j = i+1; j < studentAverages.size(); j++) {
                if (studentAverages.get(j) > studentAverages.get(i)) {
                    String temp1 = names.get(i);
                    names.set(i, names.get(j));
                    names.set(j, temp1);

                    int temp2 = numbers.get(i);
                    numbers.set(i, numbers.get(j));
                    numbers.set(j, temp2);

                    double temp3 = assignmentMarks.get(i);
                    assignmentMarks.set(i, assignmentMarks.get(j));
                    assignmentMarks.set(j, temp3);

                    double temp4 = testMarks.get(i);
                    testMarks.set(i, testMarks.get(j));
                    testMarks.set(j, temp4);

                    double temp5 = finalProjectMarks.get(i);
                    finalProjectMarks.set(i, finalProjectMarks.get(j));
                    finalProjectMarks.set(j, temp5);

                    double temp6 = studentAverages.get(i);
                    studentAverages.set(i, studentAverages.get(j));
                    studentAverages.set(j, temp6);
                }
            }
        }
        printSorted();
    }

    /**
     * printSorted() prints the student names and their corresponding averages both to the console and to a separate file
     *   > Method added to original program by Rita Xu and Aidan Wang
     */
    public void printSorted() throws IOException {
        int longest = names.get(0).length();
        for (String name : names) {
            if(name.length()>longest) {
                longest = name.length();
            }
        }

        //printing to file
        File f2 = new File("data2.txt");
        if(f2.createNewFile()) {
            System.out.println("New file created.");
            System.out.println();
        }
        FileWriter writer2 = new FileWriter(f2);
        new FileWriter("data2.txt", false).close();
        writer2.write("Name");
        for(int k=0; k<longest+1; k++) {
            writer2.write(" ");
        }
        writer2.write("Average\n");

        for(int k=0; k<names.size(); k++) {
            writer2.write(names.get(k));
            for(int m=0; m<longest+5-names.get(k).length(); m++) {
                writer2.write(" ");
            }
            writer2.write(String.format("%.2f%n", studentAverages.get(k)));
        }
        writer2.close();


        //printing to console
        System.out.print("Name");
        for(int k=0; k<longest+1; k++) {
            System.out.print(" ");
        }
        System.out.println("Average");

        for(int k=0; k<names.size(); k++) {
            System.out.print(names.get(k));
            for(int m=0; m<longest+5-names.get(k).length(); m++) {
                System.out.print(" ");
            }
            System.out.printf("%.2f%n", studentAverages.get(k));
        }
        System.out.println();
    }
}