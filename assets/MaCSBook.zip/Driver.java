import java.io.File;
import java.io.IOException;

/**
 * <h1>Driver Class</h1>
 * Creates a new MaCSBook object and runs MaCSBook methods for the object.
 *
 * <h2>Course Info:</h2>
 * ICS4U0 with Krasteva, V
 *
 * @version 03.22.2023
 * @author Aidan Wang, Rita Xu, Matthew Tsui (original Lauren Hewang, Aidan Wang)
 */
public class Driver {
    public static void main(String[] args) throws IOException {
        File file = new File("data.txt");
        if (file.createNewFile())
            System.out.println("New file created.");
        MaCSBook mb = new MaCSBook(file);
        mb.menu();
    }
}