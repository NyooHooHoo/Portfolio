/**
 * <h1>OOP 2 Creation Myth - Main Driver Class</h1>
 * <h2>Course Info:</h2>
 * ICS4U0.2 with Ms. Krasteva.
 * @author Sailesh Badri, Aidan Wang, Pouya Karimi
 * @version 21-02-2023
 */
public class Driver {
    public static void main (String[] args){
        Qarri qa1 = new Qarri();
        Qarri qa2 = new Qarri("Tree Queen", 35, 150, 100, 100, 100, "Qarri", false, 5, 10, 20, 20);
        System.out.println("Two Qarris are first created by the Creator to add some life to the world!");
        System.out.println(qa1);
        System.out.println(qa2);
        qa1.growPlant(3);
        qa2.growPlant(2);
        System.out.println("Both Qarris first create different plants, here are their heights: ");
        System.out.println(Qarri.getPlants());
        System.out.println("To maintain a stable environment the Qarris take care of the plants by frequently fertilizing them");
        qa1.fertilizePlant(1, 1);
        qa1.fertilizePlant(2, 2);
        qa1.fertilizePlant(1, 3);
        qa2.fertilizePlant(3, 4);
        qa2.fertilizePlant(1, 5);
        System.out.println(Qarri.getPlants());
        System.out.println("However there are times a Qarri has to kill a plant to ensure the survival of others, " + qa1.getName() + " doesn't have the heart to do this, but the " + qa2.getName() + " does so it Kills plant 2 to ensure the survival of other plants");
        qa2.killPlant(2);
        System.out.println(Qarri.getPlants());
        System.out.println("To ensure this continued life cycle the Qarris constantly store food and seeds");
        qa1.storeFood(50);
        qa1.storeSeeds(10);
        qa2.storeFood(50);
        qa2.storeSeeds(5);
        System.out.print(qa1.getName() + "'s Food amount: ");
        System.out.println(qa1.getFoodStored());
        System.out.print(qa1.getName() + "'s Seeds amount: ");
        System.out.println(qa1.getSeedsStored());
        System.out.print(qa2.getName() + "'s Food amount: ");
        System.out.println(qa2.getFoodStored());
        System.out.print(qa2.getName() + "'s Seeds amount: ");
        System.out.println(qa2.getSeedsStored());
        System.out.println();

        Hyrmus hy1 = new Hyrmus();
        Hyrmus hy2 = new Hyrmus("Breezy", 21, 150, 100, 100, 100, "Hyrmus", false, "Right", 10, 90.6, "Sunny");
        System.out.println("Two Hyrmus' are created after by the Creator to add atmosphere and wind control, as the plants created by Qarris needed air movement for pollination.");
        System.out.println("To moderate the world each Hyrmus changes the atomsphere's attributes near its area");
        hy1.increaseWindSpeed(10);
        hy1.decreaseWindPressure(0.8);
        hy2.decreaseWindSpeed(7);
        hy2.increaseWindPressure(10.8);
        System.out.println(hy1);
        System.out.println(hy2);
        System.out.println(hy1.getName() + " begins adding some essential gasses the atmosphere composition...");
        hy1.addGas("Nitrogen");
        hy1.addGas("Oxygen");
        hy1.addGas("Hydrogen");
        System.out.println(Hyrmus.getGasses());
        System.out.println(hy2.getName() + " has its own ideas, and changes the gasses");
        hy2.removeGas("Hydrogen");
        hy2.addGas("Carbon Dioxide");
        System.out.println(Hyrmus.getGasses());

        Iklaff ik1 = new Iklaff();
        Iklaff ik2 = new Iklaff("Oven", 12, 150, 100, 100, 100,  false);
        System.out.println("Two Iklaffs are then created by the Creator to add more structure to the world!");
        System.out.println(ik1);
        System.out.println(ik2);
        System.out.println("The Iklaffs first had to raise the temperature of the world, as it was way too cold for the plants.");
        ik1.raiseGlobalTemp(20.6);
        System.out.println();
        System.out.println("The Iklaffs create structure to the land through volanic eruptions however, since " + ik1.getName() + " thought this was too violent " + ik2.getName() + " took it upon itself to create multiple eruptions around the world.");
        ik2.makeVolcanicEruption(40);
        ik2.makeVolcanicEruption(10);
        ik2.makeVolcanicEruption(20);
        System.out.println();
        System.out.println("In this process the temperature became too hot for the plants, therefore " + ik1.getName() + " decided to decrease the temperature");
        ik1.lowerGlobalTemp(10.1);
        System.out.println();

        Swallik sw1 = new Swallik();
        Swallik sw2 = new Swallik("Wavy", 4, 150, 100, 100, 100,  false);
        System.out.println("Finally the Creator decided to add two Swalliks to take care of the Iklaffs and add more stability to the world, which completes the world.");
        System.out.println(sw1);
        System.out.println(sw2);
        System.out.println("Currently the two have set the sea level to: " + Swallik.getSeaLevel());
        System.out.println("But...");
        sw2.causeTsunami();
        System.out.println("Now the sea levels are way up: " + Swallik.getSeaLevel());
        System.out.println();
        System.out.println("The Swalliks can also summon sea creatures into the waters, first " + sw1.getName() + " adds what it wants...");
        sw1.addACreature("Squid");
        sw1.addACreature("Salmon");
        sw1.addACreature("Flying Fish");
        System.out.println();
        System.out.println(sw2.getName() + " then contributes its own ideas...");
        sw2.addACreature("Shark");
        sw2.addACreature("Hydra");
        sw2.addACreature("Kraken");
        System.out.println();
        System.out.println("It's a beautiful world the Creator has made, can't wait to see what comes next!");
    }
}