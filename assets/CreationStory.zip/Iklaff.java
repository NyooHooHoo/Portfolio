/**
 * <h1>OOP 2 Creation Myth - Iklaff Subclass</h1>
 * <h2>Course Info:</h2>
 * ICS4U0.2 with Ms. Krasteva.
 * @author Sailesh Badri, Aidan Wang, Pouya Karimi
 * @version 21-02-2023
 */
public class Iklaff extends Elemental{
    private static double globalTemperature = 20; // Static variable for the single global temperature
    private static int numOfVolcanoes = 0; // Static variable for to count total number of volcanoes in the World

    /**
     * {@link Iklaff} constructor.
     *
     * @param name name of elemental
     * @param age age of elemental
     * @param maxMana max amount of mana allowed for the elemental
     * @param maxHealth max amount of health allowed for the elemental
     * @param mana starting level of mana for the elemental
     * @param health starting level of health for the elemental
     * @param isFriendly boolean to determine whether elemental is friendly or not
     */
    public Iklaff(String name, int age, double maxMana, double maxHealth, double mana, double health, boolean isFriendly){
        super(name, age, maxMana, maxHealth, mana, health, "Iklaff", isFriendly);
    }

    /**
     * Default constructor if the user does not wish to specify all the elemental's attributes.
     */
    public Iklaff(){
        super("Iklaff");
    }

    /**
     * Evil Iklaffs cause destructive volcanic eruption on Earth's surface
     *
     * @param intensity eruption's intensity, determines mana used
     */
    public void makeVolcanicEruption(int intensity){
        if(this.isElementalFriendly()){
            System.out.println(this.getName() + " of Elemental type Iklaff is friendly, it cannot cause a volcanic eruption.");
        }
        else {
            if (this.loseMana(intensity)) {
                numOfVolcanoes += 1;
                System.out.println(this.getName() + " of Elemental type Iklaff caused a volcanic eruption. " +
                        "The number of volcanoes is now " + numOfVolcanoes);
            }
        }
    }

    /**
     * Raise overall global temperature
     *
     * @param temp amount raised
     */
    public void raiseGlobalTemp(double temp){
        if (this.loseMana(temp)) {
            System.out.println("Temperature before change: " + globalTemperature);
            globalTemperature += temp;
            System.out.println("Temperature after change: " + globalTemperature);
        }
    }

    /**
     * Lower overall global temperature
     *
     * @param temp amount lowered
     */
    public void lowerGlobalTemp(double temp){
        if (this.loseMana(temp)) {
            System.out.println("Temperature before change: " + globalTemperature);
            globalTemperature -= temp;
            System.out.println("Temperature after change: " + globalTemperature);
        }
    }

    /**
     * @return overall global temperature
     */
    public static double getGlobalTemperature() {
        return globalTemperature;
    }

    /**
     * @return total number of volcanoes
     */
    public static int getNumOfVolcanoes() {
        return numOfVolcanoes;
    }
}