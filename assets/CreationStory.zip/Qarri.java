/**
 * <h1>OOP 2 Creation Myth - Qarri Subclass</h1>
 * <h2>Course Info:</h2>
 * ICS4U0.2 with Ms. Krasteva.
 * @author Sailesh Badri, Aidan Wang, Pouya Karimi
 * @version 21-02-2023
 */
public class Qarri extends Elemental {
    private static int[] plants = new int[0]; // Static array stores heights of all plants in the World
    private int foodStored;
    private int seedsStored;
    private int maxFoodCapacity;
    private int maxSeedCapacity;

    /**
     * {@link Qarri} constructor.
     *
     * @param name          name of elemental
     * @param age           age of elemental
     * @param maxMana       max amount of mana allowed for the elemental
     * @param maxHealth     max amount of health allowed for the elemental
     * @param mana          starting level of mana for the elemental
     * @param health        starting level of health for the elemental
     * @param elementalForm elemental form
     * @param isFriendly    boolean to determine whether elemental is friendly or not
     */
    public Qarri(String name, int age, double maxMana, double maxHealth, double mana, double health, String elementalForm,
                 boolean isFriendly, int foodStored, int seedsStored, int maxFoodCapacity, int maxSeedCapacity) {
        super(name, age, maxMana, maxHealth, mana, health, elementalForm, isFriendly);
        this.foodStored = foodStored;
        this.seedsStored = seedsStored;
        this.maxFoodCapacity = maxFoodCapacity;
        this.maxSeedCapacity = maxSeedCapacity;
    }

    /**
     * Default constructor if the user does not wish to specify all the elemental's attributes.
     */
    public Qarri() {
        super("Qarri");
        this.foodStored = 10;
        this.seedsStored = 10;
        this.maxFoodCapacity = 10;
        this.maxSeedCapacity = 10;
    }

    /**
     * Grow a number of new plants using a specified number of seeds
     *
     * @param seedsUsed number of seeds used
     */
    public void growPlant(int seedsUsed) {
        if (seedsStored >= seedsUsed) {
            if (this.loseMana(5 * seedsUsed)) {
                int[] newPlants = new int[plants.length + seedsUsed];
                for (int i = 0; i < newPlants.length; i++) {
                    if (i < plants.length)
                        newPlants[i] = plants[i]; // Copy plant from existing list
                    else {
                        newPlants[i] = 0; // New plant starts with height 0
                    }
                }
                plants = newPlants;
            }
        }
        else {
            System.out.println(this.getName() + " of Elemental type Qarri doesn't have enough seeds to plant!");
        }
    }

    /**
     * Fertilizes existing plant by using food to increase height
     *
     * @param foodUsed amount of food used to fertilize plant
     * @param plantNum number to identify plant within list
     */
    public void fertilizePlant(int foodUsed, int plantNum) {
        if (plantNum <= plants.length) {
            if (this.loseMana(5 * foodUsed))
                plants[plantNum - 1] += foodUsed;
        }
        else
            System.out.println(this.getName() + " of Elemental type Qarri doesn't have enough food to fertilize Plant #" + plantNum);
    }

    /**
     * Evil Qarri kill an existing plant by removing from list
     *
     * @param plantNum number to identify plant within list
     */
    public void killPlant(int plantNum) {
        if(this.isElementalFriendly()){
            System.out.println(this.getName() + " of Elemental type Qarri is friendly, it cannot kill a plant.");
        }
        else {
            if (this.loseMana(10)) {
                int[] newPlants = new int[plants.length - 1];
                for (int i = 0; i < newPlants.length; i++) {
                    if (i != plantNum)
                        newPlants[i] = plants[i]; // Copy all plants except the one killed
                }
                plants = newPlants;
            }
            System.out.println(this.getName() + " of Elemental type Qarri has killed Plant #" + plantNum +
                    ". All plants numbers ahead of it have been reassigned.");
        }
    }

    /**
     * Increases amount of food stored by specified amount
     *
     * @param amount food to be added to storage
     */
    public void storeFood(int amount) {
        foodStored += amount;
    }

    /**
     * Increases number of seeds stored by specified amount
     *
     * @param amount seeds to be added to storage
     */
    public void storeSeeds(int amount) {
        seedsStored += amount;
    }

    /**
     * @return amount of food stored
     */
    public int getFoodStored() {
        return foodStored;
    }

    /**
     * @return percentage of food storage filled
     */
    public double getFoodPercentage() {
        return (foodStored/(double)maxFoodCapacity) * 100;
    }

    /**
     * @return number of seeds stored
     */
    public int getSeedsStored() {
        return seedsStored;
    }

    /**
     * @return percentage of seed storage filled
     */
    public double getSeedsPercentage() {
        return (seedsStored/(double)maxSeedCapacity) * 100;
    }

    /**
     * Static method returns all heights of currently planted plants
     *
     * @return String message with plant heights
     */
    public static String getPlants() {
        String message = "Current Plant Heights:" + "\n";
        for (int i = 0; i < plants.length; i++)
            message = message.concat("Plant #" + (i + 1) + ": " + plants[i] + " metres" + "\n");
        return message;
    }

    @Override
    public String toString() {
        String foodStr = "Food: " + foodStored + "/" + maxFoodCapacity + " stored, " + this.getFoodPercentage() + "%" + "\n";
        String seedsStr = "Seeds: " + seedsStored + "/" + maxSeedCapacity + " stored, " + this.getSeedsPercentage() + "%" + "\n";
        return super.toString() + foodStr + seedsStr;
    }
}