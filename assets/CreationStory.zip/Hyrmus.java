/**
 * <h1>OOP 2 Creation Myth - Hyrmus Subclass</h1>
 * <h2>Course Info:</h2>
 * ICS4U0.2 with Ms. Krasteva.
 * @author Sailesh Badri, Aidan Wang, Pouya Karimi
 * @version 21-02-2023
 */
public class Hyrmus extends Elemental{
    private static String[] gasses = new String[0]; // Static array stores the different type of gasses in the atmosphere
    private String windDirection; // variable that holds the direction of the wind
    private int windSpeed; // in km/h
    private double airPressure; // in kpa
    private String weather;

    /**
     * {@link Hyrmus} constructor.
     *
     * @param name name of elemental
     * @param age age of elemental
     * @param maxMana max amount of mana allowed for the elemental
     * @param maxHealth max amount of health allowed for the elemental
     * @param mana starting level of mana for the elemental
     * @param health starting level of health for the elemental
     * @param elementalForm the element form
     * @param isFriendly boolean to determine whether the elemental is friendly or not
     * @param windDirection describes the direction of the wind flow
     * @param windSpeed describes the speed of the wind and is measured in km/h
     * @param airPressure describes the pressure of the air and is measured in kpa
     * @param weather the weather of the world
     */
    public Hyrmus(String name, int age, double maxMana, double maxHealth, double mana, double health, String elementalForm, boolean isFriendly
            , String windDirection, int windSpeed, double airPressure, String weather){
        super(name, age, maxMana, maxHealth, mana, health, elementalForm, isFriendly);
        this.windDirection = windDirection;
        this.windSpeed = windSpeed;
        this.airPressure = airPressure;
        this.weather = weather;
    }

    /**
     * Default constructor if the user does not wish to specify all the elemental's attributes.
     */
    public Hyrmus(){
        super("Hyrmus");
        this.windDirection = "Down";
        this.windSpeed = 20;
        this.airPressure = 101.7;
        this.weather = "Snowing";
    }

    /**
     * Increases the wind speed
     *
     * @param speed amount to increase the speed by
     */
    public void increaseWindSpeed(int speed){
        if(this.loseMana(speed)) windSpeed += speed;
    }

    /**
     *Decreases the wind speed
     *
     * @param speed amount to decrease the speed by
     */
    public void decreaseWindSpeed(int speed){
        if(this.loseMana(speed)) windSpeed -= speed;
    }

    /**
     * Increases the wind pressure
     *
     * @param pressure amount to increase the wind pressure by
     */
    public void increaseWindPressure(double pressure){
        if(this.loseMana(5)) airPressure += pressure;
    }

    /**
     * Decreases the wind pressure
     * @param pressure amount to decrease the wind pressure by
     */
    public void decreaseWindPressure(double pressure){
        if(this.loseMana(5)) airPressure -= pressure;
    }

    /**
     * Sets the weather
     * @param w the weather to be set
     */
    public void setWeather(String w){
        if(this.loseMana(10)) weather = w;
    }

    /**
     * sets the wind direction
     * @param direction the direction of the wind
     */
    public void setWindDirection(String direction){
        if(this.loseMana(10)) windDirection = direction;
    }

    /**
     * Adds a gas to the atmosphere if it doesn't already exist
     * @param gas the type of gas to add
     */
    public void addGas(String gas){
        boolean exists = false;
        for(String s : gasses){
            if(s.equals(gas)) exists = true;
        }
        if(exists){
            System.out.println("The gas already exists in the atmosphere!");
        }
        else{
            if (this.loseMana(20)) {
                String[] newGasses = new String[gasses.length + 1];
                for (int i = 0; i < newGasses.length; i++) {
                    if (i < gasses.length)
                        newGasses[i] = gasses[i]; // Copy gas from existing list
                    else {
                        newGasses[i] = gas; // New gas set to the name
                    }
                }
                gasses = newGasses;
            }
        }

    }

    /**
     * Removes a gas from the atmosphere if it exists
     * @param gas the gas to remove
     */
    public void removeGas(String gas){
        boolean noExist = true;
        for(String s : gasses){
            if(s.equals(gas)) noExist = false;
        }

        if(noExist){
            System.out.println("The gas does not exist in the atmosphere, therfore it can't be removed!");
        }
        else{
            if (this.loseMana(20)) {
                String[] newGasses = new String[gasses.length - 1];
                int x = 0;
                for (int i = 0; i < gasses.length; i++) {
                    if (gasses[i] != gas){
                        newGasses[x] = gasses[i];
                        x++;
                    }
                }
                gasses = newGasses;
            }
        }
    }

    /**
     * Creates a tornado condition only if it is unfriendly
     */
    public void createTornado(){
        if(this.isElementalFriendly()){
            System.out.println(this.getName() + " of Elemental type Hyrmus is friendly, it cannot create a tornado.");
        }
        else {
            if (this.loseMana(30)) {
                windSpeed = 250;
                windDirection = "Down";
            }
        }
    }

    /**
     * @return the speed of the wind
     */
    public int getWindSpeed(){
        return windSpeed;
    }

    /**
     * @return The pressure of the air
     */
    public double getAirPressure(){
        return airPressure;
    }

    /**
     * @return The current weather condition
     */
    public String getWeather(){
        return weather;
    }

    /**
     * @return The wind direction
     */
    public String getWindDirection(){
        return windDirection;
    }

    /**
     * @return A message with all the gasses in the atmosphere
     */
    public static String getGasses(){
        String message = "Current Gasses in the atmosphere:" + "\n";
        for (int i = 0; i < gasses.length; i++)
            message = message.concat( gasses[i] + "\n");
        return message;
    }

    @Override
    public String toString() {
        String windDir = "Wind Direction: " + windDirection + "\n";
        String windSped = "Wind Speed: " + windSpeed + "\n";
        String airPres = "Air Pressure: " + airPressure + "\n";
        String w = "Weather: " + weather + "\n";
        return super.toString() + windDir + windSped + airPres + w;
    }
}