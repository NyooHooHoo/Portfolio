/**
 * <h1>OOP 2 Creation Myth - Swallik Subclass</h1>
 * <h2>Course Info:</h2>
 * ICS4U0.2 with Ms. Krasteva.
 * @author Sailesh Badri, Aidan Wang, Pouya Karimi
 * @version 21-02-2023
 */
public class Swallik extends Elemental{
    private static double seaLevel = 50; // Static variable to represent sea level around the World
    private static String[] seaCreatures = new String[0]; // Static array to store all summoned sea creatures

    /**
     * {@link Swallik} constructor.
     *
     * @param name name of elemental
     * @param age age of elemental
     * @param maxMana max amount of mana allowed for the elemental
     * @param maxHealth max amount of health allowed for the elemental
     * @param mana starting level of mana for the elemental
     * @param health starting level of health for the elemental
     * @param isFriendly boolean to determine whether elemental is friendly or not
     */
    public Swallik(String name, int age, double maxMana, double maxHealth, double mana, double health, boolean isFriendly){
        super(name, age, maxMana, maxHealth, mana, health, "Swallik", isFriendly);
    }

    /**
     * {@link Swallik} constructor
     */
    public Swallik() {
        super("Swallik");
    }

    /**
     * This method causes a tsunami only if the elemental is not friendly.
     */
    public void causeTsunami(){
        if(this.isElementalFriendly())
            System.out.println(this.getName() + " of Elemental type Swallik is friendly, it cannot cause a tsunami.");
        else {
            if (this.loseMana(10)) {
                seaLevel += 100;
                System.out.println(this.getName() + " of Elemental type Swallik caused a tsunami!");
            }
        }
    }

    /**
     * Adds a sea creature to the array of already existing sea creatures.
     * @param creature Creature to be added to the array
     */
    public void addACreature(String creature){
        String[] newArr = new String[seaCreatures.length+1];
        for (int i = 0; i<seaCreatures.length; i++){
            newArr[i] = seaCreatures[i];
        }
        newArr[newArr.length-1] = creature;
        seaCreatures = newArr;
        System.out.print("Full list of creatures is now: ");
        for(int i = 0; i<seaCreatures.length; i++){
            if (i == seaCreatures.length-1)
                System.out.println(seaCreatures[i]);
            else
                System.out.print(seaCreatures[i] + ", ");
        }
    }

    /**
     * @return Sea level
     */
    public static double getSeaLevel(){
        return seaLevel;
    }

    /**
     * @return Array of sea creatures captured by elemental
     */
    public static String[] getSeaCreatures() {
        return seaCreatures;
    }
}