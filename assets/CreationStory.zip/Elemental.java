/**
 * <h1>OOP 2 Creation Myth - Elemental Superclass</h1>
 * <h2>Course Info:</h2>
 * ICS4U0.2 with Ms. Krasteva.
 * @author Sailesh Badri, Aidan Wang, Pouya Karimi
 * @version 21-02-2023
 */
public class Elemental {
    private String name;
    private int age;
    private double maxMana; // Mana represents the energy an elemental has, this is their max amount of energy possible
    private double maxHealth;
    private double mana;
    private double health;
    private String elementalForm; // This is the form of the elemental (i.e. Qarri, Hymus, Swallik, Iklaff)
    private boolean isFriendly;

    /**
     * {@link Elemental} constructor.
     *
     * @param name name of elemental
     * @param age age of elemental
     * @param maxMana max amount of mana allowed for the elemental
     * @param maxHealth max amount of health allowed for the elemental
     * @param mana starting level of mana for the elemental
     * @param health starting level of health for the elemental
     * @param elementalForm elemental form
     * @param isFriendly boolean to determine whether elemental is friendly or not
     */
    public Elemental(String name, int age, double maxMana, double maxHealth, double mana, double health, String elementalForm, boolean isFriendly){
        this.name = name;
        this.age = age;
        this.maxMana = maxMana;
        this.maxHealth = maxHealth;
        this.mana = mana;
        this.health = health;
        this.elementalForm = elementalForm;
        this.isFriendly = isFriendly;
    }

    /**
     * Constructor to use in default constructor of subclasses, with default values for everything but elementalForm
     *
     * @param form elemental form
     */
    public Elemental(String form) {
        name = "Steve";
        age = 0;
        maxMana = 100;
        maxHealth = 100;
        mana = 100;
        health = 100;
        elementalForm = form;
        isFriendly = true;
    }

    /**
     * Default constructor if the user does not wish to specify all the elemental's attributes.
     */
    public Elemental(){
        name = "Steve";
        age = 0;
        maxMana = 100;
        maxHealth = 100;
        mana = 100;
        health = 100;
        elementalForm = "Qarri";
        isFriendly = false;
    }

    /**
     * Elemental takes damage and lose health points. If the health points reach below 0, the elemental dies.
     *
     * @param points amount of damage the elemental is taking
     */
    public void takeDamage(double points){
        health -= points;
        if(health<0){
            health = 0;
            System.out.println(name + " of Elemental type " + elementalForm + " health is now at 0. They are dead.");
        }
        else {
            System.out.println(name + " of Elemental type " + elementalForm + " health is now at " + health);
        }
    }

    /**
     * Elemental heals a certain amount of points. If the health is over the maximum health allowed, it is reset to the maximum.
     *
     * @param points amount of points to be added to their health
     */
    public void heal(double points){
        health += points;
        if(health>maxHealth) health = maxHealth;
        System.out.println(name + " of Elemental type " + elementalForm + " health is now at " + health);
    }

    /**
     * Elemental gains mana/energy. If the mana is past the allowed amount, it is reset to the maximum value.
     *
     * @param points amount of mana gained by elemental
     */
    public void addMana(double points){
        mana += points;
        if(mana>maxMana) mana = maxMana;
    }

    /**
     * Elemental loses mana/energy when completing a task.
     * If the mana is less than 0, it is set to 0 and no more tasks can be done until more mana is added.
     *
     * @param points amount of mana lost
     */
    public boolean loseMana(double points){
        if(mana<points){
            System.out.println(name + " of Elemental type " + elementalForm + "doesn't have enough mana to perform a task.");
            return false;
        }
        else {
            mana -= points;
            return true;
        }
    }

    /**
     * @return name of Elemental
     */
    public String getName() {
        return name;
    }

    /**
     * @return age of Elemental
     */
    public int getAge() {
        return age;
    }

    /**
     * Increases age by specifies number of years
     *
     * @param years number of years to increase
     */
    public void ageUp(int years) {
        age += years;
    }

    /**
     * @return the elemental form (type of elemental)
     */
    public String getElementalForm() {
        return elementalForm;
    }

    /**
     * @return boolean indicating whether the elemental is friendly or not
     */
    public boolean isElementalFriendly(){
        return isFriendly;
    }

    /**
     * @return the percentage of mana the elemental has
     */
    public double getManaPercentage(){
        return (mana/maxMana) * 100;
    }

    /**
     * @return the percentage of health the elemental has
     */
    public double getHealthPercentage(){
        return (health/maxHealth) * 100;
    }

    @Override
    public String toString() {
        String nameStr = "Name: " + name + "\n";
        String ageStr = "Age: " + age + " year(s) old" + "\n";
        String hpStr = "Health: " + this.getHealthPercentage() + "%" + "\n";
        String mpStr = "Mana: " + this.getManaPercentage() + "%" + "\n";
        String frStr = "Friendly: " + (isFriendly ? "Yes" : "No") + "\n";
        return nameStr + ageStr + hpStr + mpStr + frStr;
    }
}